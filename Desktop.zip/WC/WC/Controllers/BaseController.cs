﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Mvc;
using WC.Data;
using WC.Models;
using System.Linq;
using WC.Hubs;

namespace WC.Controllers
{
    [Authorize]
    public class BaseController : Controller
    {
        public CyberEntities db = new CyberEntities();

        public List<FriendViewModel> GetListFriendsOf(string userId)
        {
            var query = from fl in db.FriendLists
                        from f in db.Friends
                        from u in db.Users
                            //from pp in db.Profile_Photo
                        where fl.Id == f.FriendsListId
                        && f.FriendId == u.UserID
                        && fl.Id == userId
                        select new FriendViewModel()
                        {
                            FriendId = f.FriendId,
                            Name = u.FirstName + " " + u.LastName,
                            //ProfileImgUrl=pp.ProfileImageUrl
                        };
            return query.ToList();
        }

        public string GetHtmlListFriendsOf(string userId)
        {
            string html = "";
            html += RenderPartialViewToString("FriendListPartial", GetListFriendsOf(userId));
            return html;
        }

        public List<ChatHubModel> GetListChatItemOf(string fromUserId, string toUserId)
        {
            var query = from cb in db.ChatBoxes
                        from cbd in db.ChatReplies
                        from u in db.Users
                        where cb.Id == cbd.ChatBoxId
                        && (cb.FromUseId == fromUserId && cb.ToUseId == toUserId ||
                            cb.FromUseId == toUserId && cb.ToUseId == fromUserId)
                        && cbd.UserIdReply == u.UserID
                        select new ChatHubModel()
                        {
                            UserId = cbd.UserIdReply,
                            Message = cbd.Content,
                            Name = u.FirstName + " " + u.LastName,
                            ProfileImgUrl = u.Profile_Photo.ProfileImageUrl
                        };
            var data = query.ToList();
            return data;
        }
        public string GetHtmlListChatItemOf(string fromUserId, string toUserId)
        {
            string html = "";
            html += RenderPartialViewToString("ChatItemViewModel", GetListChatItemOf(fromUserId, toUserId));
            return html;
        }

        public string RenderPartialViewToString(string viewName, object model)
        {
            if (string.IsNullOrEmpty(viewName))
                viewName = ControllerContext.RouteData.GetRequiredString("action");

            ViewData.Model = model;

            using (var sw = new StringWriter())
            {
                var viewResult =
                    ViewEngines.Engines.FindPartialView(ControllerContext, viewName);
                var viewContext = new ViewContext
                    (ControllerContext, viewResult.View, ViewData, TempData, sw);
                viewResult.View.Render(viewContext, sw);

                return sw.GetStringBuilder().ToString();
            }
        }


        public static string TruncateAtWord(string input, int length)
        {
            if (input == null || input.Length < length)
                return input;
            var iNextSpace = input.LastIndexOf(" ", length, StringComparison.InvariantCultureIgnoreCase);
            return string.Format("{0}...", input.Substring(0, (iNextSpace > 0) ? iNextSpace : length).Trim());
        }

        public string GetHtmlLanguageSetting(string currentId, string targetId)
        {
            string html = "";
            var language = db.Languages.ToList();
            LanguageSettingViewModel ls = null;
            var b1 = db.SettingChatBoxes.FirstOrDefault(x => x.User1 == currentId && x.User2 == targetId);
            var b2 = db.SettingChatBoxes.FirstOrDefault(x => x.User1 == targetId && x.User2 == currentId);

            if (b1 != null && b2 == null)
            {
                ls = new LanguageSettingViewModel();
                ls.Laguages = language;
                ls.TargettUserId = targetId;
                ls.UserShowLanguage = b1.ShowLanguage1;
                ls.CurrentUserId = currentId;
                ls.UserLanguage = b1.Language1;
                ls.SettingId = b1.Id;
            }

            if (b1 == null && b2 != null)
            {
                ls = new LanguageSettingViewModel();
                ls.Laguages = language;
                ls.TargettUserId = currentId;
                ls.UserShowLanguage = b2.ShowLanguage2;
                ls.CurrentUserId = targetId;
                ls.UserLanguage = b2.Language2;
                ls.SettingId = b2.Id;
            }
            html += RenderPartialViewToString("LanguageSettingPartial", ls);
            return html;
        } 

        public string ApplySettingLanguage(string curUserId, string targetUserId, string lag1, string lag2)
        {
            var s1 = db.SettingChatBoxes.FirstOrDefault(x => x.User1 == curUserId && x.User2 == targetUserId);
            if (s1 != null)
            {
                s1.Language1 = Convert.ToInt32(lag1);
                s1.ShowLanguage1 = Convert.ToInt32(lag2);
                db.SaveChanges();
                return "1";
            }

            var s2 = db.SettingChatBoxes.FirstOrDefault(x => x.User1 == targetUserId && x.User2 == curUserId);
            if (s2 != null)
            {
                s2.Language2 = Convert.ToInt32(lag1);
                s2.ShowLanguage2 = Convert.ToInt32(lag2);
                db.SaveChanges();
            }
            return "1";
        }

    }
}