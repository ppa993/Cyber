﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WC.Hubs
{
    public class UserConnection
    {
        public string UserId { set; get; }
        public string ConnectionId { set; get; }
    }
}