﻿
function OpenSmallChatBox(e, url) {
    var id = e.getAttribute("data-item-id");
    var name = e.getAttribute("data-item-name");
    var username = e.getAttribute("data-item-user");
    //var link = '<a href="/Home/Profile/' + username + '">' + name + '</a>';
    //alert(link);
    //$("#chat-box-name").html('');
    //$("#chat-box-name").append(link);
    $("#chat-box-name").text(name);
    $("#chat-box-message").attr("data-item-toid", id);
    $("#btn-setting-language").attr("data-item-toid", id);
    var fromId = $("#chat-box-message").attr("data-item-fromid");
    $.post(url,
    {
        fromUserId: fromId,
        toUserId: id
    }, function (data) {
        if (data != "") {
            $("#chat-box-content").html('');
            $("#chat-box-content").append(data);

            $("#chat-box-content").scrollTop($("#chat-box-content").height() + 50);
        }
    });
}

$(function () {
    var chat = $.connection.chatHub;

    chat.client.broadcastMessage = function (fromUserId, toUserId, toUserName, message) {
        ClientMethods(fromUserId, toUserId, toUserName);
    };
    chat.client.recieveNotify = function (receiver, html) {
        AddNotify(receiver, html);
    }
    $.connection.hub.start().done(function () {
        $("#chat-box-message").keypress(function (event) {
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                var fromId = $("#chat-box-message").attr("data-item-fromid");
                var toId = $("#chat-box-message").attr("data-item-toid");
                var msg = $("#chat-box-message").val();
                if (fromId == "" && toId == "" && msg == "") return;
                chat.server.send(fromId, toId, msg);
                $("#chat-box-message").val('');
            }
        });
    })
});

function AddNotify(receiver, html) {
    var curId = $("#chat-box-message").attr("data-item-fromid");
    if (curId == receiver) {
        $("#notify-box").html('');
        $("#notify-box").append(html);
    }
}

function ClientMethods(fromId, toId, toUserName) {
    var id = $("#chat-box-message").attr("data-item-fromid");
    var url = $("#chat-box-message").attr("data-item-url");
    if (id != fromId && id != toId) return;

    $.post(url,
    {
        fromUserId: fromId,
        toUserId: toId
    }, function (data) {
        if (data != "") {
            if (!$("#cbp-spmenu-s2").hasClass("cbp-spmenu-open")) {
                if (id == toId) {
                    $("#btn-setting-language").attr("data-item-toid", toId);
                }

                $("#chat-box-name").text(toUserName);
                $("#cbp-spmenu-s2").toggleClass("cbp-spmenu-open");
            }

            $("#chat-box-content").html('');
            $("#chat-box-content").append(data);

            $("#chat-box-content").scrollTop($("#chat-box-content").height() + 50);
        }
    });
}

function OpenSettingLanguageModal(e, url) {
    var fromId = e.getAttribute("data-item-fromid");
    var toId = e.getAttribute("data-item-toid");

    $.post(url, { currentId: fromId, targetId: toId }, function (data) {
        var nameTarget = $("#chat-box-name").text();
        $("#languageSettingModal-title").text("Setting language chat to " + nameTarget);
        $("#submit-setting-language").attr("data-item-toid", toId);
        $('#languageSettingModal-content').html('');
        $('#languageSettingModal-content').append(data);
        $('#languageSettingModal').modal('toggle');
    });
}

function SubmitSettingLanguage(e, url) {
    var fid = e.getAttribute("data-item-fromid");
    var tid = e.getAttribute("data-item-toid");
    var url = e.getAttribute("data-item-url");
    var l1 = $("#currentLanguage").val();
    var l2 = $("#targetLanguage").val();

    $.post(url+'',
        {
            curUserId: fid,
            targetUserId: tid,
            lag1: l1,
            lag2: l2
        }, function (data) {
            alert(data);
        });
}