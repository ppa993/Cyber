﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WC.Models
{
    public class FriendViewModel
    {
        public string FriendId { set; get; }
        public string Name { set; get; }
        public string ProfileImgUrl { set; get; }
        public string Username { set; get; }
    }
}