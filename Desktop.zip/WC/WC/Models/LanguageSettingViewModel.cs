﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WC.Models
{
    public class LanguageSettingViewModel
    {
        public List<WC.Data.Language> Laguages { set; get; }
        public string CurrentUserId { set; get; }
        public int? UserLanguage { set; get; }
        public int? UserShowLanguage { set; get; }
        public string TargettUserId { set; get; } 
        public int SettingId { set; get; }
    }
}